import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:my_protfolio1/Fragment/About.dart';

import 'package:my_protfolio1/screens/home_screen.dart';
import 'package:my_protfolio1/CalculatorScreen.dart';
import 'package:my_protfolio1/screens/quiz_screen.dart';
import 'package:my_protfolio1/portfolioapp.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ThemeProvider(),
      child: Consumer<ThemeProvider>(
        builder: (context, themeProvider, child) {
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            themeMode: themeProvider.themeMode,
            theme: ThemeData.light(),
            darkTheme: ThemeData.dark(),
            home: const HomeActivity(),
          );
        },
      ),
    );
  }
}

class ThemeProvider extends ChangeNotifier {
  ThemeMode _themeMode = ThemeMode.light;

  ThemeMode get themeMode => _themeMode;

  void toggleTheme() {
    _themeMode =
        _themeMode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
    notifyListeners();
  }
}

class HomeActivity extends StatelessWidget {
  const HomeActivity({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "Arpita Sarker",
            style: Theme.of(context).textTheme.titleLarge!,
          ),
          backgroundColor: Theme.of(context).primaryColor,
          actions: [
            IconButton(
              icon: Icon(Icons.brightness_6),
              onPressed: () {
                Provider.of<ThemeProvider>(context, listen: false)
                    .toggleTheme();
              },
            ),
          ],
        ),
        drawer: Drawer(
          child: Container(
            color: Color.fromARGB(255, 153, 236, 229),
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                DrawerHeader(
                  padding: const EdgeInsets.all(0),
                  decoration: const BoxDecoration(
                      color: Color.fromARGB(221, 255, 255, 255)),
                  child: UserAccountsDrawerHeader(
                    accountName: const Text(
                      "Arpita Sarker",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      ),
                    ),
                    accountEmail: const Text(
                      "sarker15-4173@diu.edu.bd",
                      style: TextStyle(
                        fontSize: 14,
                        color: Color.fromARGB(255, 0, 0, 0),
                      ),
                    ),
                    currentAccountPicture: ClipRRect(
                      borderRadius: BorderRadius.circular(40),
                      child: Image.asset(
                          "lib/Assets/images/IMG_20211225_194742.jpg"),
                    ),
                    decoration: const BoxDecoration(
                      color: Colors.black54,
                    ),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(
                    'MyProtfolio',
                    style: Theme.of(context)
                        .textTheme
                        .titleSmall!
                        .copyWith(color: const Color.fromARGB(255, 0, 0, 0)),
                  ),
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ProfilePage(
                                  onThemeChanged: (value) {
                                    // Add any necessary logic here
                                  },
                                  isDarkMode:
                                      false, // Provide the current theme mode
                                )));
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.quiz),
                  title: Text(
                    'Quizer',
                    style: Theme.of(context)
                        .textTheme
                        .titleSmall!
                        .copyWith(color: const Color.fromARGB(255, 0, 0, 0)),
                  ),
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const QuizScreen()));
                  },
                ),
                ListTile(
                  leading: Icon(Icons.calculate),
                  title: Text(
                    'Scientific Calculator',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium!
                        .copyWith(color: Colors.black),
                  ),
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => CalculatorPage()));
                  },
                ),
                ListTile(
                  leading: Icon(Icons.cloud),
                  title: Text(
                    'Weather',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium!
                        .copyWith(color: const Color.fromARGB(255, 0, 0, 0)),
                  ),
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => HomeScreen()));
                  },
                ),
              ],
            ),
          ),
        ),
        body: const TabBarView(
          children: [
            About(),
          ],
        ),
      ),
    );
  }
}
